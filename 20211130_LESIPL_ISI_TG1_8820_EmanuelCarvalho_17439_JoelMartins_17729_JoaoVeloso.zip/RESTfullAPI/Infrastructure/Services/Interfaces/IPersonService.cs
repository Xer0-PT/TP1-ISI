﻿using System.Threading.Tasks;

namespace RestfullAPI.Infrastructure.Services
{
    public interface IPersonService
    {
        Task CheckTimeOfCovid();
    }
}
